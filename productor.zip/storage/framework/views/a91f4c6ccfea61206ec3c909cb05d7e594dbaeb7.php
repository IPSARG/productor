<?php if(Session::has('alert-message')): ?>
    <div class="alert <?php echo e(Session::get('alert-message')['alert-class']); ?> <?php echo e(Session::get('alert-message')['alert-type']); ?> alert-dismissible fade show rounded-0 border-0" role="alert">
        <button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong><?php echo e(Session::pull('alert-message')['message']); ?></strong>
    </div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger rounded-0 border-0 bg-danger text-white">
        <button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <ul class="m-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH E:\www\IPS-Trabajo\productor\resources\views/partials/_messages.blade.php ENDPATH**/ ?>