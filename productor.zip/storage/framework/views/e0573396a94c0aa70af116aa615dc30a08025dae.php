<div class="card border-0 rounded-0 shadow-sm shadower" id="sit_finalized">
    <div class="card-header border-0 rounded-0 bg-dark">
        <h4 class="header-title m-0 text-white">Cabezal armado SIT <span class="badge badge-pill badge-danger float-right"><?php echo e(count($sitNorms)); ?></span></h4>
    </div>
    <ul class="list-group list-group-flush">
        <?php if(count($sitNorms) > 0): ?>
            <?php $__currentLoopData = $sitNorms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $norm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item font-weight-bold rounded-0 bg-secondary">
                    <span class="norm_name_day text-white sit_norm"><?php echo e($norm->nt_name); ?> (<?php echo e($norm->j_acr); ?>) <?php echo e(str_replace('.', '',$norm->number)); ?> </span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <li class="list-group-item font-weight-bold rounded-0 bg-secondary">
                <span class="norm_name_day text-white sit_norm"> Ningúna norma presente </span>
            </li>
        <?php endif; ?>
    </ul>
</div>   <?php /**PATH E:\www\IPS-Trabajo\productor\resources\views/numeric/modules/sit_norms.blade.php ENDPATH**/ ?>