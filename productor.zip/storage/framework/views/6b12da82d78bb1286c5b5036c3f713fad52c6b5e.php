<?php $__env->startSection('section-title', 'Materias y Coes'); ?> 

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('arrayDescNodo')): ?>
        <div class="row">
            <div class="col-md-12 mt-4 mb-2">
                <?php echo $__env->make('partials._breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    <?php endif; ?>
    <?php if(Request::get('Prim') || Route::is('tem')): ?>
        <div class="row mt-3 mb-4">
            <div class="col-11">
                <a href="" class="btn btn-link rounded-circle bg-success shadow float-right" data-toggle="modal" data-target="#firstNode">
                    <i class="fas fa-2x fa-plus text-white pt-1"></i>
                </a>
            </div>
        </div>
        <?php echo $__env->make('thematic.modals.addFirstNode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <div class="row mb-4">
        <div class="col-10 offset-md-1">
            <?php $__currentLoopData = $tematics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tematic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card border-0 rounded-0 shadow mb-2">
                    <div class="card-body bg-white text-dark py-2">
                        <?php if(IsCoefi::isCoefi(request(), $tematic->desc_nodo)): ?>
                            <a href="<?php echo e(route('get.tem.child.coe') . '?CodNodo=' . $tematic->cod_hijo . '&DescNodo=' . $tematic->desc_nodo); ?>" class="text-reset font-weight-bold text-decoration-none"><?php echo e($tematic->desc_nodo); ?></a>
                        <?php else: ?> 
                            <a href="<?php echo e(route('get.tem.child') . '?CodNodo=' . $tematic->cod_nodo . '&DescNodo=' . $tematic->desc_nodo); ?>" class="text-reset font-weight-bold text-decoration-none"><?php echo e($tematic->desc_nodo); ?></a>
                        <?php endif; ?>
                        <?php if($tematic->desc_nodo != 'Conferencias'): ?>
                            <ul class="list-inline float-right mb-0">
                                <li class="list-inline-item">
                                    <a href="" data-toggle="modal" data-target="#interNode_<?php echo e(IsCoefi::isCoefi(request(), $tematic->desc_nodo) ? $tematic->cod_hijo : $tematic->cod_nodo); ?>">
                                        <i class="fas fa-plus-circle text-success"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="" data-toggle="modal" data-target="#editNode_<?php echo e(IsCoefi::isCoefi(request(), $tematic->desc_nodo) ? $tematic->cod_hijo : $tematic->cod_nodo); ?>">
                                        <i class="fas fa-edit text-info"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <?php if(IsCoefi::isCoefi(request(), $tematic->desc_nodo)): ?>
                                        <a href="<?php echo e(route('get.post.coe', ['cod_padre' => $tematic->cod_hijo, 'desc_nodo' => $tematic->desc_nodo])); ?>"><i class="fas fa-link text-orange"></i></a>
                                    <?php else: ?> 
                                        <a href="<?php echo e(route('get.link.norm', ['cod_nodo' => $tematic->cod_nodo, 'desc_nodo' => $tematic->desc_nodo])); ?>"><i class="fas fa-link text-secondary"></i></a>
                                    <?php endif; ?>
                                </li>
                                <li class="list-inline-item">
                                    <form action="<?php echo e(route('delete.node', IsCoefi::isCoefi(request(), $tematic->desc_nodo) ? $tematic->cod_hijo : $tematic->cod_nodo)); ?>" method="POST" class="conf_form">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('DELETE')); ?>

                                        <button class="btn btn-link p-0" type="submit">
                                            <i class="fas fa-trash-alt text-danger"></i>
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <?php echo $__env->make('thematic.modals.addInterNode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('thematic.modals.editNode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\IPS-Trabajo\productor\resources\views/thematic/index.blade.php ENDPATH**/ ?>