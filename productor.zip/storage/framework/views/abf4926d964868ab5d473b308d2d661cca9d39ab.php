<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Productor |  <?php echo $__env->yieldContent('section-title'); ?></title>

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scriptsHead'); ?><?php /**PATH E:\www\IPS-Trabajo\productor\resources\views/partials/_head.blade.php ENDPATH**/ ?>