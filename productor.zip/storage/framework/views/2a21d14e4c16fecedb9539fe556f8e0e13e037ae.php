<?php $__env->startSection('section-title', 'Normas - editar'); ?> 

<?php $__env->startSection('content'); ?>
    <div class="row mt-3">
        <div class="col-md-8 offset-md-2">
            <div class="card border-0 rounded-0 shadow shadower">
                <div class="card-body">
                    <?php echo Form::model($norm, ['route' => ['put.norm', 'id_norma' => $norm->id_norma, 'id_tipo_norma' => $norm->id_tipo_norma], 'method' => 'PUT', 'files' => true, 'data-parsley-validate' => true, 'data-parsley-errors-messages-disabled' => true]); ?>

                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 pr-1">
                                <div class="form-group">
                                    <label for="id_norma">Número</label>
                                    <input type="text" class="form-control rounded-0" name="id_norma" placeholder="165/19" value="<?php echo e($norm->id_norma); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6 pl-1">
                                <div class="form-group">
                                    <label for="id_tipo_norma">Tipo de norma</label>
                                    <select name="id_tipo_norma" class="form-control rounded-0" required>
                                        <option value="">Seleccionar...</option>
                                        <?php $__currentLoopData = $normTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $normType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($normType->id_tipo_norma == $norm->id_tipo_norma): ?>
                                                <option value="<?php echo e($normType->id_tipo_norma); ?>" selected><?php echo e($normType->desc_tipo_norma); ?> </option>
                                            <?php else: ?>
                                                <option value="<?php echo e($normType->id_tipo_norma); ?>"><?php echo e($normType->desc_tipo_norma); ?> </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="desc_norma">Descripción</label>
                            <textarea rows="5" name="desc_norma" class="form-control rounded-0" required><?php echo e($norm->desc_norma); ?></textarea>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6 pr-1">
                                    <label for="fec_norma">Fecha norma</label>
                                    <input type="date" class="form-control rounded-0" name="fec_norma" value="<?php echo e(!is_null($norm->fec_norma) ? date('Y-m-d', strtotime($norm->fec_norma)) : ''); ?>">
                                </div>
                                <div class="col-md-6 pl-1">
                                    <label for="fec_carga">Fecha carga</label>
                                    <input type="date" class="form-control rounded-0" name="fec_carga" value="<?php echo e(!is_null($norm->fec_carga) ? date('Y-m-d', strtotime($norm->fec_carga)) : ''); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6 pr-1">
                                    <label for="idtema">Tema</label>
                                    <select name="idtema" class="form-control rounded-0">
                                        <option value="">Seleccionar...</option>
                                        <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($tema->idtema == $norm->idtema): ?>
                                                <option value="<?php echo e($tema->idtema); ?>" selected><?php echo e($tema->tema); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($tema->idtema); ?>"><?php echo e($tema->tema); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-6 pl-1">
                                    <label for="norm_folder">Carpeta Archivo</label>
                                    <select name="norm_folder" class="form-control rounded-0">
                                        <option value="" <?php echo e(is_null($norm->carpeta_texto) ? 'selected' : ''); ?>>Seleccionar...</option>
                                        <option value="files" <?php echo e($norm->carpeta_texto == 'files' ? 'selected' : ''); ?>>Files</option>
                                        <option value="files/parte2" <?php echo e($norm->carpeta_texto == 'files/parte2' ? 'selected' : ''); ?>>Parte 2</option>
                                        <option value="files/parte3" <?php echo e($norm->carpeta_texto == 'files/parte3' ? 'selected' : ''); ?>>Parte 3</option>
                                        <option value="files/parte4" <?php echo e($norm->carpeta_texto == 'files/parte4' ? 'selected' : ''); ?>>Parte 4</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-0">
                            <label for="texto_norma">Archivo</label>
                            <input type="file" name="texto_norma" class="form-control-file">
                        </div>
                    </div>
                    <div class="card-footer border_top rounded-0 bg-white">
                        <div class="form-group mb-0">
                            <button type="submit" class="btn btn-default bg-trivia rounded-pill text-light border-0 shadow-sm float-right">Modificar</button>
                        </div>
                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-8 offset-md-2">
            <div class="card bg-primary text-white border-0 rounded-pill shadow-sm shadower">
                <div class="card-body pb-3">
                    <h5 class="m-0 d-inline-block">
                        <i class="fas fa-lg fa-file-alt pr-2"></i>
                        <strong><?php echo e($norm->texto_norma); ?></strong>
                    </h5>
                    <?php if(!is_null($norm->carpeta_texto)): ?>
                        <form action="<?php echo e(route('delete.norm.archive', $norm->texto_norma)); ?>" method="POST" class="d-inline-block float-right">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo csrf_field(); ?>
                            <button class="btn btn-link p-0 m-0 text-white" type="submit"><i class="fas fa-lg fa-trash"></i></button>
                        </form>
                    <?php else: ?>
                        <h5 class="text-white float-right m-0">Ruta de archivo no especificada</h5>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-12 text-center">
            <a href="<?php echo e(url()->previous()); ?>"><i class="fas fa-2x fa-long-arrow-alt-left text-secondary"></i></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\IPS-Trabajo\productor\resources\views/numeric/edit_norm.blade.php ENDPATH**/ ?>