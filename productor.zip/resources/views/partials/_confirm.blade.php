<div class="modal fade" id="confirm_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content border-0 rounded-0">
            <div class="modal-body text-center">
                <h4 class="text-dark font-weight-bold">Deseas confirmar la operación?</h4>
            </div>
            <div class="modal-footer bg-secondary border-0 rounded-0 text-center">
                <button type="button" class="btn btn-dark rounded-0" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-danger rounded-0 btn_conf text-white">Confirmo</button>
            </div>
        </div>
    </div>
</div>