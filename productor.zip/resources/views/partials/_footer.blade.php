@include('partials._confirm')
@stack('scriptsFooter')